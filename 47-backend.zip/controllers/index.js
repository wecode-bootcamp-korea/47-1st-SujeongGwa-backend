const goodController = require("./goodController");

module.exports = {
    goodController,
}